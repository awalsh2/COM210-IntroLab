/* Aidan Walsh
Program 3
*/
package com210program3;
import java.util.Scanner;
import java.util.Arrays;



public class COM210Program3 
{//start class

 
  public static void main(String[] args) 
  {//start main
      Scanner kb=new Scanner(System.in);
      int Length;
      System.out.println("How many items are you going to purchase?");
      Length=kb.nextInt();
      String Item[]=new String[Length];
      double Price[]= new double[Length];
      StringBuilder reversed=new StringBuilder();
      double total=0;
      double average;
      for(int x=0; x<Item.length; x++)
      {//start for
          System.out.println("Enter Item");
          Item[x]=kb.next();
      }//end for
      for(int x = 0; x<Price.length; x++)
      {//start for
          System.out.println("Enter Price of the Item");
          Price[x]= kb.nextDouble();
      }//end for
      
      for(int i = Item.length; i >0; i--)
      { reversed.append(Item[i -1]).append("");
      };
      String[]reversedArray=reversed.toString().split("");
      System.out.println(Arrays.toString(reversedArray));
      for(int i=0; i<Price.length; i++)
      {
          total=total+Price[i];
          
      }
          average=total/Price.length;
          for(int i=0; i<Price.length; i++)
          {
            if (Item[i].equalsIgnoreCase("apples"))
          {
            System.out.println("The average is " + average);
          
         } else {
              System.out.println("there is no average");
            }
          
          }
  
  
  }//end main

    
}//end class
