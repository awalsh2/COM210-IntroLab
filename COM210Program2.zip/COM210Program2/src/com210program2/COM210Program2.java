/* Aidan Walsh
Program2
*/
package com210program2;
import java.util.Scanner;
import java.util.Arrays;

public class COM210Program2 
{//startclass

public static void main(String[] args) 
 {//start main
     Scanner kb = new Scanner(System.in);
     String Item[]= new String[3];
     double Price[] = new double[3] ;
     
     for(int x=0; x<Item.length; x++)
     {//start for
         System.out.println("Enter the Item");
         Item[x]=kb.next();
     }//end for
     
     for(int x=0; x<Price.length; x++)
     {//start for
         System.out.println("Enter the price of the Item");
         Price[x]=kb.nextDouble();
     }//end for
     double average;
     average = (Price[0]+Price[1]+Price[2])/3;
     System.out.println(Arrays.toString(Item));
     
     if (Item[0].equalsIgnoreCase("apple"))
     {//start if
         System.out.println("The Average price of Items are " + average);
     }  else if (Item[1].equalsIgnoreCase("apple"))
     {  
        System.out.println("The Average price of Items are " + average);
      } else if (Item[2].equalsIgnoreCase("apple"))
      {
         System.out.println("The Average price of Items are " + average);
    } else
      {
        System.out.println("there is no average");
       }//end for
         
}//end main

}//end class
     
     
     
   
 
   
   
