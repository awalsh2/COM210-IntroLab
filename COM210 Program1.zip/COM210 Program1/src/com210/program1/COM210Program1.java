/* Aidan Walsh
Program1
*/
package com210.program1;
import java.util.Scanner;
import java.util.Arrays;

public class COM210Program1 
{//start class

 public static void main(String[] args) 
 {//start main
     Scanner kb = new Scanner(System.in);
     String Item[]= new String[3];
     double Price[] = new double[3] ;
     for(int x=0; x<Item.length; x++)
     {//start for
         System.out.println("Enter the Item");
         Item[x]=kb.next();
     }//end for
     
     for(int x=0; x<Price.length; x++)
     {//start for
         System.out.println("Enter the price of the Item");
         Price[x]=kb.nextDouble();
     }//end for
     
     double average;
     average = (Price[0]+Price[1]+Price[2])/3;
     System.out.println(Arrays.toString(Item));
     System.out.println("The average price of the Items are " + average);
 
    }//end main
    
}//end class
